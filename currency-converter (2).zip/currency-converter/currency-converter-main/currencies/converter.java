package currencies;
//all data rates were collected on 23-05-2021 from https://www.exchange-rates.org/
public class converter {
    protected double INR, USD, EUR, GBP, KWD, JPY, KYD;
}